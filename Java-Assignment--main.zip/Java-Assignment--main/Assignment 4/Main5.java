import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {

        Frame f = new Frame("Button Example");

        Button b = new Button("Click Me");

        b.setBounds(100, 100, 100, 40);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button Clicked");
            }
        });

        f.add(b);

        f.setSize(300, 250);
        f.setLayout(null);
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });
    }
}