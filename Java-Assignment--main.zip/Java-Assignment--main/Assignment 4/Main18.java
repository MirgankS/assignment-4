import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {

        Frame f = new Frame("WindowAdapter Example");

        f.setSize(400, 300);
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
                System.exit(0);
            }
        });
    }
}