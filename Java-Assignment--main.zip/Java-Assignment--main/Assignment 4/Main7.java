import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        JFrame f = new JFrame("My Swing App");

        f.setSize(400, 300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}